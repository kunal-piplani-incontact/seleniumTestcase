1. Which version of PhantomJS are you using? Tip: run `phantomjs --version`.

2. What steps will reproduce the problem?
  1.
  2.
  3.

3. Which operating system are you using?

4. Did you use binary PhantomJS or did you compile it from source?

5. Please provide any additional information below.
