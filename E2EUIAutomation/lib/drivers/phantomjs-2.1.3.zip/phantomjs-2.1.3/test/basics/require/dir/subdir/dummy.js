module.exports = 'subdir/dummy';
